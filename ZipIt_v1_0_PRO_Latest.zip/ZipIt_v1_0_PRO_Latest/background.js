chrome.runtime.onInstalled.addListener(() => {
    chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch((error) => console.error(error));
    chrome.sidePanel.setOptions({ path: 'popup.html', enabled: true }).catch((error) => console.error(error));
});
